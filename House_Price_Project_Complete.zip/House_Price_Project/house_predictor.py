"""California House Price Predictor - working prototype of the regression mini project

Run:  press the Play button, or  python house_predictor.py   (it starts itself in the browser)
Manual: python -m streamlit run house_predictor.py

Keep housing.csv in the same folder (it is downloaded automatically if missing).
Models (Linear, Polynomial, Decision Tree, Random Forest, SVR) are trained on first use
and cached in the app_models/ folder.
"""
import importlib.util
import os
import subprocess
import sys

# --- Bootstrap: install missing packages and start Streamlit automatically -------------
_REQUIRED = {"streamlit": "streamlit", "streamlit_folium": "streamlit-folium", "folium": "folium",
             "sklearn": "scikit-learn", "pandas": "pandas", "numpy": "numpy",
             "joblib": "joblib", "matplotlib": "matplotlib"}


def _has(mod):
    try:
        return importlib.util.find_spec(mod) is not None
    except (ValueError, ImportError):
        return mod in sys.modules


_missing = [pkg for mod, pkg in _REQUIRED.items() if not _has(mod)]
if _missing:
    print("Installing missing packages:", ", ".join(_missing), flush=True)
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *_missing])
    except Exception:
        sys.exit("Could not install: " + ", ".join(_missing) + "\n"
                 f"Run:  {sys.executable} -m pip install " + " ".join(_missing))

import streamlit as st  # noqa: E402
from streamlit.runtime.scriptrunner import get_script_run_ctx  # noqa: E402

try:
    _in_streamlit = get_script_run_ctx(suppress_warning=True) is not None
except TypeError:
    _in_streamlit = get_script_run_ctx() is not None
if not _in_streamlit:  # started with Play / "python house_predictor.py" -> relaunch properly
    print("Starting the app in your browser (keep this window open, Ctrl+C to stop)...", flush=True)
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", os.path.abspath(__file__),
                        "--browser.gatherUsageStats=false"])
    except KeyboardInterrupt:
        pass
    sys.exit(0)

import folium  # noqa: E402
import joblib  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor  # noqa: E402
from sklearn.ensemble import RandomForestRegressor  # noqa: E402
from sklearn.impute import SimpleImputer  # noqa: E402
from sklearn.linear_model import LinearRegression, Ridge  # noqa: E402
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score  # noqa: E402
from sklearn.model_selection import train_test_split  # noqa: E402
from sklearn.neighbors import NearestNeighbors  # noqa: E402
from sklearn.pipeline import Pipeline  # noqa: E402
from sklearn.preprocessing import OneHotEncoder, PolynomialFeatures, StandardScaler  # noqa: E402
from sklearn.svm import SVR  # noqa: E402
from sklearn.tree import DecisionTreeRegressor  # noqa: E402
from streamlit_folium import st_folium  # noqa: E402

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "housing.csv")
MODEL_DIR = os.path.join(BASE, "app_models")
URL = "https://raw.githubusercontent.com/ageron/handson-ml/master/datasets/housing/housing.csv"
SEED = 42
CATS = ["<1H OCEAN", "INLAND", "ISLAND", "NEAR BAY", "NEAR OCEAN"]
PRESETS = {"Los Angeles": (34.05, -118.25), "San Francisco": (37.77, -122.42), "San Diego": (32.72, -117.16),
           "Sacramento": (38.58, -121.49), "Fresno": (36.74, -119.79), "Santa Barbara": (34.42, -119.70)}
POLY_COLS = ["longitude", "latitude", "median_income", "housing_median_age"]


# ------------------------------- data -----------------------------------------
@st.cache_data(show_spinner="Loading data...")
def load_data():
    if os.path.exists(DATA_FILE):
        df = pd.read_csv(DATA_FILE)
    else:
        df = pd.read_csv(URL)
        df.to_csv(DATA_FILE, index=False)
    return df


def add_features(d):
    d = d.copy()
    d["rooms_per_household"] = d["total_rooms"] / d["households"]
    d["bedrooms_per_room"] = d["total_bedrooms"] / d["total_rooms"]
    d["population_per_household"] = d["population"] / d["households"]
    return d


@st.cache_data(show_spinner=False)
def split_data():
    df = add_features(load_data())
    y, X = df["median_house_value"], df.drop(columns="median_house_value")
    segment = pd.qcut(y, 3, labels=["Low", "Medium", "High"]).astype(str)   # same split as the notebook
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=SEED, stratify=segment)
    return Xtr, Xte, ytr, yte, [float(v) for v in y.quantile([1 / 3, 2 / 3])]


@st.cache_resource(show_spinner=False)
def neighbour_index():
    df = load_data()
    return NearestNeighbors(n_neighbors=25, metric="haversine").fit(np.radians(df[["latitude", "longitude"]].values))


def nearby(lat, lon):
    dist, idx = neighbour_index().kneighbors(np.radians([[lat, lon]]))
    return load_data().iloc[idx[0]], dist[0] * 6371.0


# ------------------------------- models ---------------------------------------
def _num_cols():
    return [c for c in split_data()[0].columns if c != "ocean_proximity"]


def _base_steps():
    return [("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]


def preprocess():
    return ColumnTransformer([
        ("num", Pipeline(_base_steps()), _num_cols()),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), ["ocean_proximity"])])


def poly_preprocess(degree):
    return ColumnTransformer([
        ("poly", Pipeline(_base_steps() + [("pf", PolynomialFeatures(degree, include_bias=False)),
                                           ("scale2", StandardScaler())]), POLY_COLS),
        ("rest", Pipeline(_base_steps()), [c for c in _num_cols() if c not in POLY_COLS]),
        ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), ["ocean_proximity"])])


MODELS = {
    "Random Forest": lambda: Pipeline([("prep", preprocess()), ("model", RandomForestRegressor(
        n_estimators=100, random_state=SEED, n_jobs=-1))]),
    "SVR (RBF)": lambda: Pipeline([("prep", preprocess()), ("model", TransformedTargetRegressor(
        regressor=SVR(C=10), transformer=StandardScaler()))]),
    "Polynomial Regression (deg 4)": lambda: Pipeline([("prep", poly_preprocess(4)), ("model", Ridge(alpha=1))]),
    "Decision Tree (pruned)": lambda: Pipeline([("prep", preprocess()), ("model", DecisionTreeRegressor(
        max_depth=16, min_samples_leaf=20, random_state=SEED))]),
    "Linear Regression": lambda: Pipeline([("prep", preprocess()), ("model", LinearRegression())]),
}
NOTES = {"Random Forest": "Best accuracy in the project (many decision trees averaged).",
         "SVR (RBF)": "Flexible non-linear model; slower to train (about a minute).",
         "Polynomial Regression (deg 4)": "Linear model with curved terms for location, income and age.",
         "Decision Tree (pruned)": "Simple rules; depth-limited to reduce overfitting.",
         "Linear Regression": "Fast, interpretable straight-line baseline."}


def _path(name):
    return os.path.join(MODEL_DIR, "".join(c if c.isalnum() else "_" for c in name) + ".joblib")


def is_trained(name):
    return os.path.exists(_path(name))


@st.cache_resource(show_spinner=False)
def get_model(name):
    """Load a trained model from disk, or train it (first use only) and save it."""
    p = _path(name)
    if os.path.exists(p):
        try:
            return joblib.load(p)
        except Exception:  # e.g. saved with another scikit-learn version -> retrain
            pass
    Xtr, Xte, ytr, yte, _ = split_data()
    pipe = MODELS[name]().fit(Xtr, ytr)
    pred = pipe.predict(Xte)
    mse = mean_squared_error(yte, pred)
    bundle = {"pipe": pipe, "pred": pred,
              "metrics": {"MAE": mean_absolute_error(yte, pred), "MSE": mse, "RMSE": float(np.sqrt(mse)),
                          "R2": r2_score(yte, pred), "Train R2": r2_score(ytr, pipe.predict(Xtr))}}
    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(bundle, p, compress=3)
    return bundle


def predict_price(pipe, row):
    r = add_features(pd.DataFrame([row]))
    return float(pipe.predict(r[split_data()[0].columns])[0])


# --------------------------------- UI -----------------------------------------
st.set_page_config(page_title="California House Price Predictor", page_icon="🏠", layout="wide")
st.title("🏠 California House Price Predictor")
st.caption("Regression mini-project prototype · California Housing (1990 census) · scikit-learn")

df = load_data()
Xtr, Xte, ytr, yte, cuts = split_data()
st.session_state.setdefault("pt", PRESETS["Los Angeles"])

with st.sidebar:
    st.header("Model")
    model_name = st.selectbox("Regression algorithm", list(MODELS), index=0)
    st.caption(NOTES[model_name])
    if not is_trained(model_name):
        st.info("First use: training this model now (Random Forest ≈ 30–60 s, SVR ≈ 1–2 min).")
    with st.spinner(f"Preparing {model_name}..."):
        bundle = get_model(model_name)
    m = bundle["metrics"]
    st.metric("Test R²", f"{m['R2']:.3f}")
    st.metric("Test RMSE (typical error)", f"${m['RMSE']:,.0f}")
    st.metric("Test MAE", f"${m['MAE']:,.0f}")
    st.divider()
    st.header("Quick location")
    preset = st.selectbox("Jump to a city", ["(click the map)"] + list(PRESETS))
    if preset != "(click the map)" and st.session_state.get("last_preset") != preset:
        st.session_state["pt"] = PRESETS[preset]
        st.session_state["last_preset"] = preset
    elif preset == "(click the map)":
        st.session_state["last_preset"] = None

tab_pred, tab_perf, tab_about = st.tabs(["🔮 Predict", "📊 Model performance", "ℹ️ About"])

# ------------------------------ Predict tab -----------------------------------
with tab_pred:
    lat, lon = st.session_state["pt"]
    near, dist_km = nearby(lat, lon)
    left, right = st.columns([3, 2])

    with right:
        st.subheader("Neighbourhood details")
        st.caption("Pre-filled with typical values of the 25 nearest block groups — change them freely.")
        key = f"{lat:.3f}_{lon:.3f}"
        income = st.slider("Median income (×$10,000)", 0.5, 15.0, float(round(near["median_income"].median(), 1)), 0.1, key=f"inc_{key}")
        age = st.slider("Median housing age (years)", 1, 52, int(near["housing_median_age"].median()), key=f"age_{key}")
        households = st.number_input("Households", 1, 6000, int(max(1, near["households"].median())), 10, key=f"hh_{key}")
        rooms = st.number_input("Total rooms", 2, 40000, int(near["total_rooms"].median()), 50, key=f"rm_{key}")
        bedrooms = st.number_input("Total bedrooms", 1, 7000, int(near["total_bedrooms"].median()), 10, key=f"bd_{key}")
        population = st.number_input("Population", 3, 36000, int(near["population"].median()), 50, key=f"pop_{key}")
        cat_default = near["ocean_proximity"].iloc[:10].mode()[0]
        ocean = st.selectbox("Ocean proximity", CATS, index=CATS.index(cat_default), key=f"oc_{key}")

    row = dict(longitude=lon, latitude=lat, housing_median_age=age, total_rooms=rooms, total_bedrooms=bedrooms,
               population=population, households=households, median_income=income, ocean_proximity=ocean)
    price = predict_price(bundle["pipe"], row)
    rmse = m["RMSE"]
    segment = "Low" if price < cuts[0] else ("Medium" if price < cuts[1] else "High")
    local_avg = float(near["median_house_value"].mean())

    with left:
        st.caption("Click the map to choose a location (the 25 nearest block groups are shown, coloured by real price).")
        fmap = folium.Map(location=[lat, lon], zoom_start=9, tiles="OpenStreetMap")

        def colour(v):
            return "#2c7bb6" if v < 150000 else "#7fbf7b" if v < 250000 else "#fdae61" if v < 350000 else "#d7191c"

        for _, r in near.iterrows():
            folium.CircleMarker([r["latitude"], r["longitude"]], radius=5, color=colour(r["median_house_value"]),
                                fill=True, fill_opacity=0.8, weight=1,
                                tooltip=f"actual ${r['median_house_value']:,.0f}").add_to(fmap)
        folium.Marker([lat, lon], tooltip="Selected location", icon=folium.Icon(color="black", icon="home")).add_to(fmap)
        click = st_folium(fmap, height=430, width=None, key="map", returned_objects=["last_clicked"])
        if click and click.get("last_clicked"):
            new = (round(click["last_clicked"]["lat"], 4), round(click["last_clicked"]["lng"], 4))
            if new != tuple(round(v, 4) for v in st.session_state["pt"]):
                st.session_state["pt"] = new
                st.rerun()
        st.caption("🔵 < $150k   🟢 $150–250k   🟠 $250–350k   🔴 > $350k")

    if dist_km[0] > 25:
        st.warning(f"This point is {dist_km[0]:.0f} km from the nearest block group in the dataset — "
                   "it is outside the area the model knows, so treat the estimate with caution.")
    a, b, c, d = st.columns(4)
    a.metric("Predicted house value", f"${price:,.0f}")
    b.metric("Typical range (± RMSE)", f"${max(price - rmse, 0) / 1e3:,.0f}k – ${(price + rmse) / 1e3:,.0f}k")
    c.metric("Price segment", segment, help=f"Low < ${cuts[0]:,.0f} ≤ Medium < ${cuts[1]:,.0f} ≤ High")
    d.metric("Nearby real average", f"${local_avg:,.0f}", delta=f"{price - local_avg:+,.0f} vs prediction")
    st.caption(f"Location {lat:.4f}, {lon:.4f} · model: **{model_name}** · the value is the *median house value of a "
               "neighbourhood*, not the price of a single house.")

    with st.expander("What-if analysis: how does income change the predicted price?"):
        grid = pd.DataFrame([row] * 30)
        grid["median_income"] = np.linspace(1, 10, 30)
        preds = bundle["pipe"].predict(add_features(grid)[Xtr.columns])
        fig, ax = plt.subplots(figsize=(7, 3.2))
        ax.plot(grid["median_income"], preds, color="seagreen", lw=2)
        ax.axvline(income, color="gray", ls="--", label="current income")
        ax.set_xlabel("median income (×$10,000)"); ax.set_ylabel("predicted value ($)"); ax.legend(); ax.grid(alpha=0.3)
        st.pyplot(fig); plt.close(fig)

# ----------------------------- Performance tab --------------------------------
with tab_perf:
    st.subheader("Model comparison (test set: 20% unseen neighbourhoods)")
    trained = [n for n in MODELS if is_trained(n)]
    if len(trained) < len(MODELS):
        if st.button("Train & compare all models (a few minutes the first time)"):
            bar = st.progress(0.0)
            for i, n in enumerate(MODELS):
                with st.spinner(f"Training {n}..."):
                    get_model(n)
                bar.progress((i + 1) / len(MODELS))
            st.rerun()
    base_pred = np.full(len(yte), ytr.mean())
    rows = [{"Model": "Baseline (always the average)", "MAE": mean_absolute_error(yte, base_pred),
             "MSE": mean_squared_error(yte, base_pred), "RMSE": float(np.sqrt(mean_squared_error(yte, base_pred))),
             "R2": r2_score(yte, base_pred), "Train R2": 0.0}]
    for n in MODELS:
        if is_trained(n):
            rows.append({"Model": n, **get_model(n)["metrics"]})
    table = pd.DataFrame(rows).set_index("Model")
    st.dataframe(table.style.format({"MAE": "{:,.0f}", "MSE": "{:,.0f}", "RMSE": "{:,.0f}", "R2": "{:.3f}", "Train R2": "{:.3f}"}),
                 width="stretch")
    st.caption("Large gap between Train R² and Test R² = overfitting. MSE is in dollars².")

    if len(table) > 2:
        t2 = table.drop(index=table.index[0])
        fig, ax = plt.subplots(1, 2, figsize=(12, 3.8))
        t2["R2"].plot.barh(ax=ax[0], color="steelblue"); ax[0].set_title("R² (higher is better)")
        t2["RMSE"].plot.barh(ax=ax[1], color="tomato"); ax[1].set_title("RMSE in $ (lower is better)")
        plt.tight_layout(); st.pyplot(fig); plt.close(fig)

    st.subheader(f"Error analysis — {model_name}")
    pred = bundle["pred"]
    err = yte.values - pred
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.2))
    ax[0].scatter(yte, pred, s=5, alpha=0.2, color="teal")
    lim = [yte.min(), yte.max()]; ax[0].plot(lim, lim, "r--")
    ax[0].set_title("Actual vs predicted"); ax[0].set_xlabel("actual ($)"); ax[0].set_ylabel("predicted ($)")
    ax[1].hist(err, bins=60, color="slategray", edgecolor="white"); ax[1].axvline(0, color="red")
    ax[1].set_title("Residuals (actual − predicted)")
    bins = pd.cut(yte, [0, 100e3, 200e3, 300e3, 400e3, 500e3, 600e3],
                  labels=["<100k", "100-200k", "200-300k", "300-400k", "400-500k", "500k+ cap"])
    mae_by = pd.Series(np.abs(err), index=yte.index).groupby(bins, observed=True).mean()
    ax[2].bar(mae_by.index.astype(str), mae_by.values, color="darkorange"); ax[2].tick_params(axis="x", rotation=25)
    ax[2].set_title("Mean absolute error by actual price")
    for a_ in ax:
        a_.grid(alpha=0.3)
    plt.tight_layout(); st.pyplot(fig); plt.close(fig)
    rel = np.abs(err) / yte.values
    st.write(f"**{100 * (rel <= 0.10).mean():.1f}%** of predictions are within ±10% of the true value and "
             f"**{100 * (rel <= 0.20).mean():.1f}%** within ±20%.")

    final = bundle["pipe"].named_steps["model"]
    names = [n.split("__")[-1] for n in bundle["pipe"].named_steps["prep"].get_feature_names_out()]
    if hasattr(final, "feature_importances_"):
        imp = pd.Series(final.feature_importances_, index=names).sort_values().tail(10)
        fig, ax = plt.subplots(figsize=(7, 3.8)); ax.barh(imp.index, imp.values, color="seagreen")
        ax.set_title("Top feature importances"); plt.tight_layout(); st.pyplot(fig); plt.close(fig)
    elif model_name == "Linear Regression":
        coef = pd.Series(final.coef_, index=names).sort_values()
        fig, ax = plt.subplots(figsize=(7, 4.5))
        ax.barh(coef.index, coef.values, color=["tomato" if v < 0 else "seagreen" for v in coef.values])
        ax.set_title("Linear Regression coefficients (effect on price, $)"); plt.tight_layout(); st.pyplot(fig); plt.close(fig)

# -------------------------------- About tab -----------------------------------
with tab_about:
    st.markdown(f"""
### What this prototype does
It predicts the **median house value of a California neighbourhood** (census block group) from its location, income,
housing age, size, population and ocean proximity — the regression problem defined in the project notebook.

**Dataset:** California Housing (1990 US census), {len(df):,} block groups. Target `median_house_value` is capped at $500,000.
**Preprocessing:** median imputation of `total_bedrooms`, three engineered ratios (rooms/bedrooms/people per household),
standard scaling, one-hot encoding of `ocean_proximity` — all inside a scikit-learn `Pipeline` (no data leakage).
**Models:** Linear Regression, Polynomial Regression (degree 4 + Ridge), Decision Tree (pruned), Random Forest, SVR (RBF).
**Metrics:** MAE, MSE, RMSE, R² on a held-out 20% test set (random seed {SEED}).

### Limitations
- 1990 data and a price cap at $500k → the model under-predicts the most expensive areas.
- Predicts neighbourhood averages, **not** the price of an individual house.
- Random train/test split is optimistic for completely new regions; points far from California are unreliable.
- Not financial advice.
""")
