# 🏠 House Price Prediction — California Housing (ML Mini Project)

Predicting neighbourhood house values with regression, and price segments (Low / Medium / High) with classification. Includes EDA, an automated profiling report, seven regression algorithms, six classifiers, evaluation metrics, hyperparameter tuning, and a working web app.

## ⚡ Quick start (Windows)

1. **Unzip** the downloaded folder.
2. **Web app:** double-click `run_predictor.bat` (needs Python; it installs what it needs and opens your browser).
3. **No-install version:** double-click `house_price_web.html`. It opens in any browser.
4. **Notebook:** open `House_Price_ML_Project.ipynb` in Jupyter / VS Code / Google Colab, or just open `House_Price_ML_Project.html` to read it with all outputs.
5. **Profiling report:** open `housing_profiling_report.html` in a browser.

> Tip: to get a PDF of the notebook for submission, open `House_Price_ML_Project.html` in a browser and print it (Ctrl+P → Save as PDF).

---

## 1. Problem & use case

**Question:** given a neighbourhood's income, housing age, size, population and location, how much is a typical house worth?

| Task | Target | Type |
|------|--------|------|
| Regression | `median_house_value` (USD) | continuous |
| Classification | `price_class` = Low / Medium / High (terciles of price) | 3 balanced classes |

**Who benefits:** home buyers and investors, real-estate entrepreneurs, banks/valuers, city planners.

## 2. Dataset

**California Housing (1990 US Census)**: 20,640 rows × 10 columns. Each row is a *census block group* (a neighbourhood), not a single house.

| Feature | Meaning |
|---------|---------|
| `longitude`, `latitude` | Location |
| `housing_median_age` | Median age of houses (years) |
| `total_rooms`, `total_bedrooms` | Totals in the block group (207 bedroom values missing) |
| `population`, `households` | People / households |
| `median_income` | Median income (×$10,000) |
| `ocean_proximity` | `<1H OCEAN`, `INLAND`, `NEAR OCEAN`, `NEAR BAY`, `ISLAND` |
| `median_house_value` | **Target**, capped at $500,000 |

Source copy: `ageron/handson-ml` on GitHub (original: Pace & Barry, 1997, StatLib).

## 3. Project files

| File | Purpose |
|------|---------|
| `House_Price_ML_Project.ipynb` | Main Jupyter notebook (already executed, with outputs) |
| `House_Price_ML_Project.html` | Same notebook as a static page |
| `House_Price_Regression_Walkthrough.ipynb` / `.html` | **Explained walkthrough** of the regression project: for every step, what we did, why, and how the code works (figure numbers match the report) |
| `housing_profiling_report.html` | Automated profiling report (ydata-profiling, formerly pandas-profiling) |
| `housing.csv` | The dataset |
| `house_predictor.py` | Streamlit web app running the regression models locally |
| `run_predictor.bat` | Windows double-click launcher for the app |
| `requirements_app.txt` | Packages needed by the app |
| `house_price_web.html` | Standalone browser version of the predictor (compact Random Forest) |
| `earth_engine_version/` | Optional extra: house-price app that reads satellite features from Google Earth Engine (see its own notes) |

## 4. What the notebook covers

| Section | Content |
|---------|---------|
| 1–2 | Use case, feature dictionary, loading and first look |
| 3 | Profiling report |
| 4 | EDA with Matplotlib: missing values, target distribution, histograms, box plots, correlation heatmap, income vs price, price map of California, `ocean_proximity` analysis, scatter matrix, each explained |
| 5 | Preprocessing: median imputation, 3 engineered ratio features, scaling, one-hot encoding, stratified 80/20 split, all inside pipelines (no leakage) |
| 6 | **Regression mini project**: problem definition, Linear / Polynomial / Ridge / Lasso / Decision Tree / Random Forest / SVR (+ baseline), MAE, MSE, RMSE, R², tuning, error analysis, limitations, demonstration |
| 7 | **Classification**: Naive Bayes, Logistic Regression, Linear classifier (SGD), KNN, Decision Tree, Random Forest; accuracy, precision, recall, F1, ROC-AUC, confusion matrices |
| 8 | Hyperparameter tuning of the classifiers: GridSearchCV, RandomizedSearchCV, validation curve |
| 9 | Feature importance, final comparison, conclusions |

### Rubric map (Regression Mini Project, 10 marks)

| Criterion | Where |
|-----------|-------|
| Problem definition (1) | §6.1 |
| Dataset & preprocessing (2) | §1–5 |
| Model selection & implementation (2) | §6.2 |
| Evaluation: MAE, MSE, RMSE, R² (2) | §6.3–6.4 |
| Results & interpretation (1) | §6.5–6.6 |
| Code quality & demonstration (2) | §6.7 and the web app |

## 5. Key results

### Regression (test set, 4,128 unseen neighbourhoods)

| Model | MAE ($) | RMSE ($) | R² |
|-------|--------:|---------:|---:|
| Baseline (always the average) | 92,201 | 116,844 | 0.000 |
| Linear / Ridge / Lasso | ≈ 49,500 | ≈ 68,700 | 0.654 |
| Polynomial Regression (tuned, degree 4) | 44,741 | 63,914 | 0.701 |
| Decision Tree (default → pruned) | 44,928 → 38,917 | 70,182 → 58,711 | 0.639 → 0.747 |
| SVR (RBF, tuned) | 36,553 | 56,134 | 0.769 |
| **Random Forest** | **33,025** | **50,439** | **0.814** |

The un-pruned Decision Tree overfits (train R² 1.00 vs test 0.64). Tuning did not improve the Random Forest (0.812 tuned vs 0.814 default).

**Error analysis:** 43.7% of Random Forest predictions are within ±10% of the true value and 70.5% within ±20%. Errors grow with price, and the $500k cap causes 11% of the total error from only about 5% of the rows.

### Classification (price segment)

| Model | Accuracy | F1 (macro) | ROC-AUC |
|-------|---------:|-----------:|--------:|
| **Random Forest (tuned)** | **0.821** | **0.821** | **0.943** |
| KNN (tuned) | 0.747 | 0.749 | 0.903 |
| Decision Tree (tuned) | 0.744 | 0.747 | 0.889 |
| Logistic Regression | 0.741 | 0.741 | 0.891 |
| Linear classifier, SGD (tuned) | 0.715 | 0.707 | 0.864 |
| Naive Bayes (tuned) | 0.625 | 0.626 | 0.830 |

Tuning helped most for Naive Bayes (F1 +0.14) and the SGD classifier (+0.05), modestly for KNN, Decision Tree and Random Forest, and not at all for Logistic Regression.

## 6. How to run

### Notebook
```bash
pip install pandas numpy matplotlib scikit-learn ydata-profiling jupyter
jupyter notebook House_Price_ML_Project.ipynb
```
Keep `housing.csv` next to the notebook, then choose **Run All**. A full run takes roughly 10–15 minutes.

> If `ydata-profiling` will not install on a very new Python (e.g. 3.14), use Python 3.10–3.12 or Google Colab. Only the profiling cell needs it. The pre-generated `housing_profiling_report.html` can be submitted as is.

### Web app (local)
Put `house_predictor.py` and `housing.csv` in one folder, then either press ▶ in VS Code, double-click `run_predictor.bat`, or run:
```bash
python house_predictor.py
```
It installs missing packages, starts Streamlit and opens `http://localhost:8501`. The first launch trains the Random Forest (about a minute) and caches models in `app_models/`.

**App features:** click a map location (or pick a city) → neighbourhood details are pre-filled from the 25 nearest real neighbourhoods → live price prediction with a likely range, price segment and the local real average; model selector (Random Forest, SVR, Polynomial, Decision Tree, Linear); model-comparison and error-analysis tab.

### Standalone browser version
Open `house_price_web.html` in any browser. It needs no installation. It uses a compact 40-tree Random Forest (test R² 0.798, RMSE ≈ $52.6k) instead of the notebook's full model (R² 0.814).

## 7. Limitations

1. **Capped target:** values above $500,000 are recorded as $500,001, so the most expensive areas are under-predicted.
2. **1990 data:** the model would need retraining on current data before real-world use.
3. **Neighbourhood averages, not houses:** it cannot value an individual property.
4. **Optimistic split:** a random train/test split puts neighbouring areas in both sets; a brand-new region would score lower.
5. **Missing price drivers:** school quality, crime, distance to jobs and time trends are not in the data.
6. Tuning used a 6,000-row sample for speed.

## 8. Future work

- Add satellite-derived features from Google Earth Engine (greenery/NDVI, built-up density, night lights, distance to water) and train on current Indian listings (e.g. Pune).
- Use spatial cross-validation and a log-transformed target.
- Deploy the Streamlit app publicly (e.g. Streamlit Community Cloud).

## 9. Tech stack

Python · pandas · NumPy · Matplotlib · scikit-learn · ydata-profiling · Streamlit · Folium · Jupyter

---
*Educational project. Not financial advice.*
