EARTH ENGINE VERSION (optional extra)
Run: double-click run_app.bat (or python house_app.py). Needs a Google Cloud project registered for Earth Engine; project id pre-filled: house-price-510108.
Demo mode uses real satellite data but SYNTHETIC prices. Not tested against live Earth Engine when built, so a small fix may be needed on first run.
