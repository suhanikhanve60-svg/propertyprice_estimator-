"""Diagnostic: finds which Earth Engine dataset is empty/unavailable.
Run:  python check_ee.py
"""
import ee

PROJECT = "house-price-510108"
ee.Initialize(project=PROJECT)
pt = ee.Geometry.Point([73.8567, 18.5204])  # Pune

tests = {
    "Sentinel-2": lambda: ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterDate("2024-01-01", "2025-12-31").filterBounds(pt).size().getInfo(),
    "VIIRS night lights": lambda: ee.ImageCollection("NOAA/VIIRS/DNB/MONTHLY_V1/VCMCFG")
        .size().getInfo(),
    "Population density": lambda: ee.ImageCollection("CIESIN/GPWv411/GPW_Population_Density")
        .size().getInfo(),
    "Dynamic World": lambda: ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
        .filterDate("2024-01-01", "2025-12-31").filterBounds(pt).size().getInfo(),
    "SRTM elevation": lambda: ee.Image("USGS/SRTMGL1_003").bandNames().getInfo(),
    "Surface water": lambda: ee.Image("JRC/GSW1_4/GlobalSurfaceWater").bandNames().getInfo(),
}
for name, fn in tests.items():
    try:
        print(f"{name:20s} OK  ->", fn())
    except Exception as e:
        print(f"{name:20s} PROBLEM ->", str(e)[:150])
