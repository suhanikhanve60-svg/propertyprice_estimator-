@echo off
cd /d "%~dp0"
python house_predictor.py
pause
